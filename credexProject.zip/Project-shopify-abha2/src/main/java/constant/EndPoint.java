package constant;

public class EndPoint {
	public static String SHOPIFY_STORE_DOMAIN = "aakritiproject.myshopify.com";
	public static String SHOPIFY_TOKKEN = "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";
}
